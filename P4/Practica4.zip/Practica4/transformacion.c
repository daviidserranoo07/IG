#include "transformacion.h"

using namespace std;

Transformacion::Transformacion() : Nodo(){

}
